package CustomJDBC;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2016-04-13 20:30:23 AST
// -----( ON-HOST: Pokala

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.softwareag.util.IDataMap;
import javax.resource.cci.Connection;
import com.wm.pkg.art.ns.ConnectionDataNode;
import com.wm.pkg.art.ns.ConnectionDataNodeManager;
import com.wm.pkg.art.ns.ConnectionResource;
import com.wm.pkg.art.transaction.ConnectionState;
import com.wm.adapter.wmjdbc.connection.ConnectionInfo;
import com.wm.adk.cci.connection.WmConnection;
import com.wm.adapter.wmjdbc.connection.JDBCConnection;
import java.sql.Statement;
import java.sql.ResultSet;
// --- <<IS-END-IMPORTS>> ---

public final class service

{
	// ---( internal utility methods )---

	final static service _instance = new service();

	static service _newInstance() { return new service(); }

	static service _cast(Object o) { return (service)o; }

	// ---( server methods )---




	public static final void getJDBCConnection (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getJDBCConnection)>> ---
		// @sigtype java 3.5
		// [i] field:0:required connectionName
		IDataMap ipipe = new IDataMap(pipeline);
		String connName = ipipe.getAsString("connectionName");
		if(connName != null && !connName.trim().isEmpty()){
			try{
				ConnectionDataNode node = ConnectionDataNodeManager.getConnectionDataNode(connName);
				ConnectionResource resource = null;
				if (node != null) {
					resource = node.getConnectionResource();
				}
				Connection connection = null;
				ConnectionState connectionState = ConnectionState.getConnectionState();
				connection = connectionState.getConnection(resource, null);
		
				WmConnection wmConnection = (WmConnection)connection;
				ConnectionInfo cInfo =((JDBCConnection)wmConnection.getManagedConnection()).getConnectionInfo();
				java.sql.Connection dbCon = cInfo.getConnection();
				Statement stmt = dbCon.createStatement();
				String sql;
				sql = "SELECT 8 from dual";
				ResultSet rs = stmt.executeQuery(sql);
				while(rs.next()){
					//Retrieve by column name
					int id  = rs.getInt(1);				          				
					//Display values
					ipipe.put("dual", id);
				}
				//STEP 6: Clean-up environment
				rs.close();
				stmt.close();
				dbCon.close();
			}
			catch(Exception e){
				throw new ServiceException(e);
			}	
		}
		else{
			throw new ServiceException("connectionName is mandatory");
		}						
		// --- <<IS-END>> ---

                
	}
}

